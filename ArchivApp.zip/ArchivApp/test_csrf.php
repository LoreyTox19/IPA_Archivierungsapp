<?php
session_start();
?>
<form action="/ArchivApp/users/toggle_active.php" method="post">
    <input type="hidden" name="id" value="2">
    <input type="hidden" name="csrf_token" value="fake-token-123">
    <button type="submit">Test mit falschem Token</button>
</form>