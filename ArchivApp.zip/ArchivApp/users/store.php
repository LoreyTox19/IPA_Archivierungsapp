<?php

declare(strict_types=1);

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/role_check.php';

requireRole(['admin']);

if (!isPostRequest()) {
    redirect('/ArchivApp/users/create.php');
}
validateCsrfToken();

$name = trim($_POST['name'] ?? '');
$email = trim($_POST['email'] ?? '');
$password = $_POST['password'] ?? '';
$role = trim($_POST['role'] ?? '');

$_SESSION['old_user'] = [
    'name' => $name,
    'email' => $email,
    'role' => $role
];

$allowedRoles = ['admin', 'benutzer', 'gast'];
$errors = [];

if ($name === '') {
    $errors[] = 'Der Name ist ein Pflichtfeld.';
}

if (mb_strlen($name) > 100) {
    $errors[] = 'Der Name darf maximal 100 Zeichen lang sein.';
}

if ($email === '') {
    $errors[] = 'Die E-Mail ist ein Pflichtfeld.';
} elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors[] = 'Bitte eine gültige E-Mail-Adresse eingeben.';
}

if ($password === '') {
    $errors[] = 'Das Passwort ist ein Pflichtfeld.';
} elseif (mb_strlen($password) < 6) {
    $errors[] = 'Das Passwort muss mindestens 6 Zeichen lang sein.';
}

if (!in_array($role, $allowedRoles, true)) {
    $errors[] = 'Bitte eine gültige Rolle auswählen.';
}

$checkStmt = $pdo->prepare("SELECT id FROM users WHERE email = :email LIMIT 1");
$checkStmt->execute(['email' => $email]);
$existingUser = $checkStmt->fetch();

if ($existingUser) {
    $errors[] = 'Die E-Mail-Adresse ist bereits vergeben.';
}

if (!empty($errors)) {
    setFlashMessage('danger', implode(' ', $errors));
    redirect('/ArchivApp/users/create.php');
}

$passwordHash = password_hash($password, PASSWORD_DEFAULT);

$insertStmt = $pdo->prepare("
    INSERT INTO users (
        name,
        email,
        password_hash,
        role
    ) VALUES (
        :name,
        :email,
        :password_hash,
        :role
    )
");

$insertStmt->execute([
    'name' => $name,
    'email' => $email,
    'password_hash' => $passwordHash,
    'role' => $role
]);

unset($_SESSION['old_user']);

setFlashMessage('success', 'Der Benutzer wurde erfolgreich erstellt.');
redirect('/ArchivApp/users/list.php');
