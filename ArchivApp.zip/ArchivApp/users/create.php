<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/role_check.php';

requireRole(['admin']);

$flash = getFlashMessage();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="h2 mb-1">Neuen Benutzer erstellen</h1>
        <p class="text-muted mb-0">Neuen Benutzer erfassen und Rolle vergeben</p>
    </div>
    <a href="/ArchivApp/users/list.php" class="btn btn-outline-secondary">Zurück zur Benutzerübersicht</a>
</div>

<?php if ($flash): ?>
    <div class="alert alert-<?php echo escape($flash['type']); ?>">
        <?php echo escape($flash['message']); ?>
    </div>
<?php endif; ?>

<div class="card shadow-sm">
    <div class="card-body">
        <form action="/ArchivApp/users/store.php" method="post">
            <?php echo csrfField(); ?>
            <div class="row g-3">
                <div class="col-md-6">
                    <label for="name" class="form-label">Name *</label>
                    <input
                        type="text"
                        class="form-control"
                        id="name"
                        name="name"
                        required
                        maxlength="100"
                        value="<?php echo escape($_SESSION['old_user']['name'] ?? ''); ?>">
                </div>

                <div class="col-md-6">
                    <label for="email" class="form-label">E-Mail *</label>
                    <input
                        type="email"
                        class="form-control"
                        id="email"
                        name="email"
                        required
                        maxlength="150"
                        value="<?php echo escape($_SESSION['old_user']['email'] ?? ''); ?>">
                </div>

                <div class="col-md-6">
                    <label for="password" class="form-label">Passwort *</label>
                    <input
                        type="password"
                        class="form-control"
                        id="password"
                        name="password"
                        required>
                </div>

                <div class="col-md-6">
                    <label for="role" class="form-label">Rolle *</label>
                    <?php $oldRole = $_SESSION['old_user']['role'] ?? 'gast'; ?>
                    <select class="form-select" id="role" name="role" required>
                        <option value="admin" <?php echo $oldRole === 'admin' ? 'selected' : ''; ?>>admin</option>
                        <option value="benutzer" <?php echo $oldRole === 'benutzer' ? 'selected' : ''; ?>>benutzer</option>
                        <option value="gast" <?php echo $oldRole === 'gast' ? 'selected' : ''; ?>>gast</option>
                    </select>
                </div>
            </div>

            <div class="mt-4 d-flex gap-2">
                <button type="submit" class="btn btn-primary">Benutzer speichern</button>
                <a href="/ArchivApp/users/list.php" class="btn btn-outline-secondary">Abbrechen</a>
            </div>
        </form>
    </div>
</div>

<?php
unset($_SESSION['old_user']);
require_once __DIR__ . '/../includes/footer.php';
?>