<?php

declare(strict_types=1);

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/role_check.php';

requireRole(['admin']);

$stmt = $pdo->query("
    SELECT
        id,
        name,
        email,
        role,
        is_active,
        created_at
    FROM users
    ORDER BY id DESC
");

$users = $stmt->fetchAll();
$flash = getFlashMessage();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="h2 mb-1">Benutzerverwaltung</h1>
        <p class="text-muted mb-0">Alle registrierten Benutzer im Überblick</p>
    </div>
    <div class="d-flex gap-2">
        <a href="/ArchivApp/users/create.php" class="btn btn-primary">Neuer Benutzer</a>
        <a href="/ArchivApp/dashboard.php" class="btn btn-outline-secondary">Zurück zum Dashboard</a>
    </div>
</div>

<?php if ($flash): ?>
    <div class="alert alert-<?php echo escape($flash['type']); ?>">
        <?php echo escape($flash['message']); ?>
    </div>
<?php endif; ?>

<div class="card shadow-sm">
    <div class="card-body">
        <?php if (empty($users)): ?>
            <div class="alert alert-info mb-0">
                Es sind keine Benutzer vorhanden.
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-striped table-hover align-middle">
                    <thead class="table-dark">
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>E-Mail</th>
                            <th>Rolle</th>
                            <th>Status</th>
                            <th>Erstellt am</th>
                            <th>Aktionen</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $user): ?>
                            <tr>
                                <td><?php echo escape((string) $user['id']); ?></td>
                                <td><?php echo escape($user['name']); ?></td>
                                <td><?php echo escape($user['email']); ?></td>
                                <td><?php echo escape($user['role']); ?></td>
                                <td><?php echo (int) $user['is_active'] === 1 ? 'Aktiv' : 'Deaktiviert'; ?></td>
                                <td><?php echo escape($user['created_at']); ?></td>
                                <td>
                                    <div class="d-flex gap-2 flex-wrap">
                                        <a href="/ArchivApp/users/edit.php?id=<?php echo (int) $user['id']; ?>" class="btn btn-sm btn-outline-primary">
                                            Bearbeiten
                                        </a>

                                        <?php if ((int) $user['id'] !== (int) ($_SESSION['user_id'] ?? 0)): ?>
                                            <form action="/ArchivApp/users/toggle_active.php" method="post" onsubmit="return confirm('Möchtest du den Status dieses Benutzers ändern?');">
                                                <?php echo csrfField(); ?>
                                                <input type="hidden" name="id" value="<?php echo (int) $user['id']; ?>">
                                                <button type="submit" class="btn btn-sm <?php echo (int) $user['is_active'] === 1 ? 'btn-outline-warning' : 'btn-outline-success'; ?>">
                                                    <?php echo (int) $user['is_active'] === 1 ? 'Deaktivieren' : 'Reaktivieren'; ?>
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>