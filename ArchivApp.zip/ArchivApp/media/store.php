<?php

declare(strict_types=1);

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/role_check.php';

requireRole(['admin', 'benutzer']);

if (!isPostRequest()) {
    redirect('/ArchivApp/media/create.php');
}
validateCsrfToken();

$title = trim($_POST['title'] ?? '');
$description = trim($_POST['description'] ?? '');
$mediaType = trim($_POST['media_type'] ?? '');
$recordedDate = trim($_POST['recorded_date'] ?? '');
$status = trim($_POST['status'] ?? '');
$archiveFlag = $_POST['archive_flag'] ?? '0';

$_SESSION['old'] = [
    'title' => $title,
    'description' => $description,
    'media_type' => $mediaType,
    'recorded_date' => $recordedDate,
    'status' => $status,
    'archive_flag' => $archiveFlag
];

$allowedMediaTypes = ['Betacam', 'VHS', 'MiniDV', 'DVD'];
$allowedStatuses = ['erfasst', 'in_digitalisierung', 'digitalisiert', 'archiviert'];

$errors = [];

if ($title === '') {
    $errors[] = 'Der Titel ist ein Pflichtfeld.';
}

if (mb_strlen($title) > 255) {
    $errors[] = 'Der Titel darf maximal 255 Zeichen lang sein.';
}

if (!in_array($mediaType, $allowedMediaTypes, true)) {
    $errors[] = 'Bitte einen gültigen Medientyp auswählen.';
}

if (!in_array($status, $allowedStatuses, true)) {
    $errors[] = 'Bitte einen gültigen Status auswählen.';
}

if (!in_array($archiveFlag, ['0', '1'], true)) {
    $errors[] = 'Ungültiger Archivierungswert.';
}

if ($recordedDate !== '') {
    $dateObject = DateTime::createFromFormat('Y-m-d', $recordedDate);
    $dateErrors = DateTime::getLastErrors();

    if (!$dateObject || $dateErrors['warning_count'] > 0 || $dateErrors['error_count'] > 0) {
        $errors[] = 'Bitte ein gültiges Aufnahmedatum eingeben.';
    } elseif ($recordedDate > date('Y-m-d')) {
        $errors[] = 'Das Aufnahmedatum darf nicht in der Zukunft liegen.';
    }
}

if (!empty($errors)) {
    setFlashMessage('danger', implode(' ', $errors));
    redirect('/ArchivApp/media/create.php');
}

$stmt = $pdo->prepare("
    INSERT INTO media (
        title,
        description,
        media_type,
        recorded_date,
        status,
        archive_flag,
        created_by
    ) VALUES (
        :title,
        :description,
        :media_type,
        :recorded_date,
        :status,
        :archive_flag,
        :created_by
    )
");

$stmt->execute([
    'title' => $title,
    'description' => $description !== '' ? $description : null,
    'media_type' => $mediaType,
    'recorded_date' => $recordedDate !== '' ? $recordedDate : null,
    'status' => $status,
    'archive_flag' => (int) $archiveFlag,
    'created_by' => (int) $_SESSION['user_id']
]);

$newMediaId = (int) $pdo->lastInsertId();

$historyStmt = $pdo->prepare("
    INSERT INTO media_status_history (
        media_id,
        old_status,
        new_status,
        changed_by,
        comment
    ) VALUES (
        :media_id,
        :old_status,
        :new_status,
        :changed_by,
        :comment
    )
");

$historyStmt->execute([
    'media_id' => $newMediaId,
    'old_status' => null,
    'new_status' => $status,
    'changed_by' => (int) $_SESSION['user_id'],
    'comment' => 'Medium erstmals erfasst'
]);

unset($_SESSION['old']);

setFlashMessage('success', 'Das Medium wurde erfolgreich gespeichert.');
redirect('/ArchivApp/media/list.php');
