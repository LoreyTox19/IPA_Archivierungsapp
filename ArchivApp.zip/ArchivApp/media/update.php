<?php

declare(strict_types=1);

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/role_check.php';

requireRole(['admin', 'benutzer']);

if (!isPostRequest()) {
    redirect('/ArchivApp/media/list.php');
}
validateCsrfToken();

$id = (int) ($_POST['id'] ?? 0);

$title = trim($_POST['title'] ?? '');
$description = trim($_POST['description'] ?? '');
$mediaType = trim($_POST['media_type'] ?? '');
$recordedDate = trim($_POST['recorded_date'] ?? '');
$status = trim($_POST['status'] ?? '');
$archiveFlag = $_POST['archive_flag'] ?? '0';

if ($id <= 0 || $title === '') {
    setFlashMessage('danger', 'Ungültige Eingabe.');
    redirect('/ArchivApp/media/list.php');
}

// Altes Medium holen
$stmt = $pdo->prepare("SELECT status FROM media WHERE id = :id");
$stmt->execute(['id' => $id]);
$old = $stmt->fetch();

if (!$old) {
    setFlashMessage('danger', 'Medium nicht gefunden.');
    redirect('/ArchivApp/media/list.php');
}

$oldStatus = $old['status'];

// Update
$stmt = $pdo->prepare("
    UPDATE media SET
        title = :title,
        description = :description,
        media_type = :media_type,
        recorded_date = :recorded_date,
        status = :status,
        archive_flag = :archive_flag
    WHERE id = :id
");

$stmt->execute([
    'title' => $title,
    'description' => $description !== '' ? $description : null,
    'media_type' => $mediaType,
    'recorded_date' => $recordedDate !== '' ? $recordedDate : null,
    'status' => $status,
    'archive_flag' => (int) $archiveFlag,
    'id' => $id
]);

// Wenn Status geändert wurde → History
if ($oldStatus !== $status) {
    $stmt = $pdo->prepare("
        INSERT INTO media_status_history 
        (media_id, old_status, new_status, changed_by, comment)
        VALUES (:media_id, :old_status, :new_status, :changed_by, :comment)
    ");

    $stmt->execute([
        'media_id' => $id,
        'old_status' => $oldStatus,
        'new_status' => $status,
        'changed_by' => $_SESSION['user_id'],
        'comment' => 'Status geändert'
    ]);
}

setFlashMessage('success', 'Medium erfolgreich aktualisiert.');
redirect('/ArchivApp/media/list.php');
