<?php

declare(strict_types=1);

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/role_check.php';

requireRole(['admin', 'benutzer', 'gast']);

$id = (int) ($_GET['id'] ?? 0);

if ($id <= 0) {
    setFlashMessage('danger', 'Ungültige Medium-ID.');
    redirect('/ArchivApp/media/list.php');
}

$mediaStmt = $pdo->prepare("
    SELECT
        m.*,
        u.name AS created_by_name
    FROM media m
    INNER JOIN users u ON m.created_by = u.id
    WHERE m.id = :id
    LIMIT 1
");
$mediaStmt->execute(['id' => $id]);

$media = $mediaStmt->fetch();

if (!$media) {
    setFlashMessage('danger', 'Medium nicht gefunden.');
    redirect('/ArchivApp/media/list.php');
}

$historyStmt = $pdo->prepare("
    SELECT
        msh.id,
        msh.old_status,
        msh.new_status,
        msh.changed_at,
        msh.comment,
        u.name AS changed_by_name
    FROM media_status_history msh
    INNER JOIN users u ON msh.changed_by = u.id
    WHERE msh.media_id = :media_id
    ORDER BY msh.changed_at DESC, msh.id DESC
");
$historyStmt->execute(['media_id' => $id]);

$historyItems = $historyStmt->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="h2 mb-1">Medium-Details</h1>
        <p class="text-muted mb-0"><?php echo escape($media['title']); ?></p>
    </div>
    <div class="d-flex gap-2">
        <a href="/ArchivApp/media/edit.php?id=<?php echo (int) $media['id']; ?>" class="btn btn-primary">Bearbeiten</a>
        <a href="/ArchivApp/media/list.php" class="btn btn-outline-secondary">Zurück zur Übersicht</a>
    </div>
</div>

<div class="card shadow-sm mb-4">
    <div class="card-body">
        <div class="row g-3">
            <div class="col-md-6">
                <strong>Titel:</strong><br>
                <?php echo escape($media['title']); ?>
            </div>

            <div class="col-md-3">
                <strong>Medientyp:</strong><br>
                <?php echo escape($media['media_type']); ?>
            </div>

            <div class="col-md-3">
                <strong>Status:</strong><br>
                <?php echo escape($media['status']); ?>
            </div>

            <div class="col-md-3">
                <strong>Aufnahmedatum:</strong><br>
                <?php echo escape($media['recorded_date'] ?? '-'); ?>
            </div>

            <div class="col-md-3">
                <strong>Archiviert:</strong><br>
                <?php echo (int) $media['archive_flag'] === 1 ? 'Ja' : 'Nein'; ?>
            </div>

            <div class="col-md-3">
                <strong>Erstellt von:</strong><br>
                <?php echo escape($media['created_by_name']); ?>
            </div>

            <div class="col-md-3">
                <strong>Erstellt am:</strong><br>
                <?php echo escape($media['created_at']); ?>
            </div>

            <div class="col-12">
                <strong>Beschreibung:</strong><br>
                <?php echo $media['description'] !== null && $media['description'] !== ''
                    ? nl2br(escape($media['description']))
                    : '-'; ?>
            </div>
        </div>
    </div>
</div>

<div class="card shadow-sm">
    <div class="card-body">
        <h2 class="h5 mb-3">Statusverlauf dieses Mediums</h2>

        <?php if (empty($historyItems)): ?>
            <div class="alert alert-info mb-0">
                Für dieses Medium sind keine Statusänderungen vorhanden.
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-striped table-hover align-middle">
                    <thead class="table-dark">
                        <tr>
                            <th>ID</th>
                            <th>Alter Status</th>
                            <th>Neuer Status</th>
                            <th>Geändert von</th>
                            <th>Geändert am</th>
                            <th>Kommentar</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($historyItems as $item): ?>
                            <tr>
                                <td><?php echo escape((string) $item['id']); ?></td>
                                <td><?php echo escape($item['old_status'] ?? '-'); ?></td>
                                <td><?php echo escape($item['new_status']); ?></td>
                                <td><?php echo escape($item['changed_by_name']); ?></td>
                                <td><?php echo escape($item['changed_at']); ?></td>
                                <td><?php echo escape($item['comment'] ?? '-'); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>