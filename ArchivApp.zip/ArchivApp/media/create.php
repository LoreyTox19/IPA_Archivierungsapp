<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/role_check.php';
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/functions.php';

requireRole(['admin', 'benutzer']);


$flash = getFlashMessage();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="h2 mb-1">Neues Medium erfassen</h1>
        <p class="text-muted mb-0">Erfassung eines neuen Archivmediums</p>
    </div>
    <a href="/ArchivApp/media/list.php" class="btn btn-outline-secondary">Zurück zur Übersicht</a>
</div>

<?php if ($flash): ?>
    <div class="alert alert-<?php echo escape($flash['type']); ?>">
        <?php echo escape($flash['message']); ?>
    </div>
<?php endif; ?>

<div class="card shadow-sm">
    <div class="card-body">
        <form action="/ArchivApp/media/store.php" method="post">
            <?php echo csrfField(); ?>
            <div class="row g-3">
                <div class="col-md-8">
                    <label for="title" class="form-label">Titel *</label>
                    <input
                        type="text"
                        class="form-control"
                        id="title"
                        name="title"
                        required
                        maxlength="255"
                        value="<?php echo escape($_SESSION['old']['title'] ?? ''); ?>">
                </div>

                <div class="col-md-4">
                    <label for="media_type" class="form-label">Medientyp *</label>
                    <select class="form-select" id="media_type" name="media_type" required>
                        <option value="">Bitte wählen</option>
                        <?php
                        $mediaTypes = ['Betacam', 'VHS', 'MiniDV', 'DVD'];
                        $oldMediaType = $_SESSION['old']['media_type'] ?? '';

                        foreach ($mediaTypes as $type):
                        ?>
                            <option value="<?php echo escape($type); ?>" <?php echo $oldMediaType === $type ? 'selected' : ''; ?>>
                                <?php echo escape($type); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="col-md-4">
                    <label for="recorded_date" class="form-label">Aufnahmedatum</label>
                    <input
                        type="date"
                        class="form-control"
                        id="recorded_date"
                        name="recorded_date"
                        value="<?php echo escape($_SESSION['old']['recorded_date'] ?? ''); ?>">
                </div>

                <div class="col-md-4">
                    <label for="status" class="form-label">Status *</label>
                    <select class="form-select" id="status" name="status" required>
                        <?php
                        $statuses = ['erfasst', 'in_digitalisierung', 'digitalisiert', 'archiviert'];
                        $oldStatus = $_SESSION['old']['status'] ?? 'erfasst';

                        foreach ($statuses as $status):
                        ?>
                            <option value="<?php echo escape($status); ?>" <?php echo $oldStatus === $status ? 'selected' : ''; ?>>
                                <?php echo escape($status); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="col-md-4">
                    <label for="archive_flag" class="form-label">Archiviert?</label>
                    <select class="form-select" id="archive_flag" name="archive_flag">
                        <?php $oldArchiveFlag = $_SESSION['old']['archive_flag'] ?? '0'; ?>
                        <option value="0" <?php echo $oldArchiveFlag === '0' ? 'selected' : ''; ?>>Nein</option>
                        <option value="1" <?php echo $oldArchiveFlag === '1' ? 'selected' : ''; ?>>Ja</option>
                    </select>
                </div>

                <div class="col-12">
                    <label for="description" class="form-label">Beschreibung</label>
                    <textarea
                        class="form-control"
                        id="description"
                        name="description"
                        rows="4"><?php echo escape($_SESSION['old']['description'] ?? ''); ?></textarea>
                </div>
            </div>

            <div class="mt-4 d-flex gap-2">
                <button type="submit" class="btn btn-primary">Medium speichern</button>
                <a href="/ArchivApp/media/list.php" class="btn btn-outline-secondary">Abbrechen</a>
            </div>
        </form>
    </div>
</div>

<?php
unset($_SESSION['old']);
require_once __DIR__ . '/../includes/footer.php';
?>