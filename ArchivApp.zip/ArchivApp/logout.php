<?php

declare(strict_types=1);

require_once __DIR__ . '/includes/functions.php';

$_SESSION = [];
session_destroy();

session_start();
setFlashMessage('success', 'Erfolgreich ausgeloggt.');

redirect('/ArchivApp/login.php');