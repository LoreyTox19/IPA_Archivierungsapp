<?php

declare(strict_types=1);

require_once __DIR__ . '/functions.php';

if (!isLoggedIn()) {
    setFlashMessage('danger', 'Bitte zuerst einloggen.');
    redirect('/ArchivApp/login.php');
}