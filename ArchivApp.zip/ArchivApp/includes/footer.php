<?php

declare(strict_types=1);
?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="/ArchivApp/assets/js/app.js"></script>
</body>
</html>