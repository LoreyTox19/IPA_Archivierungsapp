<?php

declare(strict_types=1);

$host = 'ipa.lorenzolai.senorciego.com';
$dbname = 'ipalorenzolai';
$username = 'ipalorenzolai';
$password = 'LwWAcqtgdt4e4^0%';

try {
    $pdo = new PDO(
        "mysql:host={$host};dbname={$dbname};charset=utf8mb4",
        $username,
        $password,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );
} catch (PDOException $e) {
    exit('Fehler bei der Datenbankverbindung.');
}