<?php

declare(strict_types=1);

require_once __DIR__ . '/includes/functions.php';

$_SESSION = [];
session_destroy();

// Start a fresh session only to carry the flash message to the login page
session_start();
setFlashMessage('success', 'Erfolgreich ausgeloggt.');

redirect('/ArchivApp/login.php');
