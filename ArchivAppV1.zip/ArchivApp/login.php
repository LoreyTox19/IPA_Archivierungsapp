<?php

declare(strict_types=1);

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/functions.php';

if (isLoggedIn()) {
    redirect('/ArchivApp/dashboard.php');
}

$errorMessage = '';

if (isPostRequest()) {
    validateCsrfToken();

    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($email === '' || $password === '') {
        $errorMessage = 'Bitte E-Mail und Passwort eingeben.';
    } else {
        $stmt = $pdo->prepare(
            'SELECT id, name, email, password_hash, role, is_active FROM users WHERE email = :email LIMIT 1'
        );
        $stmt->execute(['email' => $email]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password_hash'])) {
            if ((int) $user['is_active'] !== 1) {
                $errorMessage = 'Dieser Benutzer ist deaktiviert und kann sich nicht anmelden.';
            } else {
                session_regenerate_id(true);

                $_SESSION['user_id']    = (int) $user['id'];
                $_SESSION['user_name']  = $user['name'];
                $_SESSION['user_email'] = $user['email'];
                $_SESSION['user_role']  = $user['role'];

                setFlashMessage('success', 'Login erfolgreich.');
                redirect('/ArchivApp/dashboard.php');
            }
        } else {
            $errorMessage = 'Ungültige E-Mail oder Passwort.';
        }
    }
}

$flash = getFlashMessage();

require_once __DIR__ . '/includes/header.php';
?>

<div class="row justify-content-center">
    <div class="col-md-6 col-lg-5">
        <div class="card shadow-sm">
            <div class="card-body">
                <h1 class="h3 mb-4 text-center">Login</h1>

                <?php if ($flash): ?>
                    <div class="alert alert-<?php echo escape($flash['type']); ?>">
                        <?php echo escape($flash['message']); ?>
                    </div>
                <?php endif; ?>

                <?php if ($errorMessage !== ''): ?>
                    <div class="alert alert-danger">
                        <?php echo escape($errorMessage); ?>
                    </div>
                <?php endif; ?>

                <form method="post" action="">
                    <?php echo csrfField(); ?>
                    <div class="mb-3">
                        <label for="email" class="form-label">E-Mail</label>
                        <input
                            type="email"
                            class="form-control"
                            id="email"
                            name="email"
                            required
                            value="<?php echo escape($_POST['email'] ?? ''); ?>">
                    </div>

                    <div class="mb-3">
                        <label for="password" class="form-label">Passwort</label>
                        <input
                            type="password"
                            class="form-control"
                            id="password"
                            name="password"
                            required>
                    </div>

                    <div class="d-grid">
                        <button type="submit" class="btn btn-primary">Einloggen</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
