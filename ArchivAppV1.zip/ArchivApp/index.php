<?php

header('Location: /ArchivApp/login.php');
exit;
