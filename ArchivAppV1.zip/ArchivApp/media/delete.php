<?php

declare(strict_types=1);

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/role_check.php';

requireRole(['admin']);

if (!isPostRequest()) {
    redirect('/ArchivApp/media/list.php');
}

validateCsrfToken();

$id = (int) ($_POST['id'] ?? 0);

if ($id <= 0) {
    setFlashMessage('danger', 'Ungültige Medium-ID.');
    redirect('/ArchivApp/media/list.php');
}

$stmt = $pdo->prepare('SELECT title FROM media WHERE id = :id LIMIT 1');
$stmt->execute(['id' => $id]);
$media = $stmt->fetch();

if (!$media) {
    setFlashMessage('danger', 'Medium nicht gefunden.');
    redirect('/ArchivApp/media/list.php');
}

$stmt = $pdo->prepare('DELETE FROM media WHERE id = :id');
$stmt->execute(['id' => $id]);

setFlashMessage('success', 'Das Medium "' . $media['title'] . '" wurde erfolgreich gelöscht.');
redirect('/ArchivApp/media/list.php');
