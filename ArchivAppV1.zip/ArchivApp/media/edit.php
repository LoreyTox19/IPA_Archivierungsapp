<?php

declare(strict_types=1);

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/role_check.php';

requireRole(['admin', 'benutzer']);

$id = (int) ($_GET['id'] ?? 0);

if ($id <= 0) {
    redirect('/ArchivApp/media/list.php');
}

$stmt = $pdo->prepare('SELECT * FROM media WHERE id = :id LIMIT 1');
$stmt->execute(['id' => $id]);
$media = $stmt->fetch();

if (!$media) {
    setFlashMessage('danger', 'Medium nicht gefunden.');
    redirect('/ArchivApp/media/list.php');
}

$flash = getFlashMessage();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="h2 mb-1">Medium bearbeiten</h1>
        <p class="text-muted mb-0"><?php echo escape($media['title']); ?></p>
    </div>
    <a href="/ArchivApp/media/list.php" class="btn btn-outline-secondary">Zurück</a>
</div>

<?php if ($flash): ?>
    <div class="alert alert-<?php echo escape($flash['type']); ?>">
        <?php echo escape($flash['message']); ?>
    </div>
<?php endif; ?>

<div class="card shadow-sm">
    <div class="card-body">
        <form action="/ArchivApp/media/update.php" method="post">
            <?php echo csrfField(); ?>
            <input type="hidden" name="id" value="<?php echo (int) $media['id']; ?>">

            <div class="row g-3">
                <div class="col-md-8">
                    <label for="title" class="form-label">Titel *</label>
                    <input
                        type="text"
                        class="form-control"
                        id="title"
                        name="title"
                        required
                        maxlength="255"
                        value="<?php echo escape($media['title']); ?>">
                </div>

                <div class="col-md-4">
                    <label for="media_type" class="form-label">Medientyp *</label>
                    <select class="form-select" id="media_type" name="media_type" required>
                        <?php foreach (ALLOWED_MEDIA_TYPES as $type): ?>
                            <option value="<?php echo escape($type); ?>"
                                <?php echo $media['media_type'] === $type ? 'selected' : ''; ?>>
                                <?php echo escape($type); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="col-md-4">
                    <label for="recorded_date" class="form-label">Aufnahmedatum</label>
                    <input
                        type="date"
                        class="form-control"
                        id="recorded_date"
                        name="recorded_date"
                        value="<?php echo escape($media['recorded_date'] ?? ''); ?>">
                </div>

                <div class="col-md-4">
                    <label for="status" class="form-label">Status *</label>
                    <select class="form-select" id="status" name="status" required>
                        <?php foreach (ALLOWED_STATUSES as $status): ?>
                            <option value="<?php echo escape($status); ?>"
                                <?php echo $media['status'] === $status ? 'selected' : ''; ?>>
                                <?php echo escape($status); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="col-md-4">
                    <label for="archive_flag" class="form-label">Archiviert?</label>
                    <select class="form-select" id="archive_flag" name="archive_flag">
                        <option value="0" <?php echo (int) $media['archive_flag'] === 0 ? 'selected' : ''; ?>>Nein</option>
                        <option value="1" <?php echo (int) $media['archive_flag'] === 1 ? 'selected' : ''; ?>>Ja</option>
                    </select>
                </div>

                <div class="col-12">
                    <label for="description" class="form-label">Beschreibung</label>
                    <textarea
                        class="form-control"
                        id="description"
                        name="description"
                        rows="4"><?php echo escape($media['description'] ?? ''); ?></textarea>
                </div>
            </div>

            <div class="mt-4 d-flex gap-2">
                <button type="submit" class="btn btn-primary">Speichern</button>
                <a href="/ArchivApp/media/list.php" class="btn btn-outline-secondary">Abbrechen</a>
            </div>
        </form>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
