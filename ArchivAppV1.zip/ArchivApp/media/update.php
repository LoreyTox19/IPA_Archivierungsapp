<?php

declare(strict_types=1);

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/role_check.php';

requireRole(['admin', 'benutzer']);

if (!isPostRequest()) {
    redirect('/ArchivApp/media/list.php');
}

validateCsrfToken();

$id          = (int) ($_POST['id'] ?? 0);
$title       = trim($_POST['title'] ?? '');
$description = trim($_POST['description'] ?? '');
$mediaType   = trim($_POST['media_type'] ?? '');
$recordedDate = trim($_POST['recorded_date'] ?? '');
$status      = trim($_POST['status'] ?? '');
$archiveFlag = $_POST['archive_flag'] ?? '0';

if ($id <= 0) {
    setFlashMessage('danger', 'Ungültige Eingabe.');
    redirect('/ArchivApp/media/list.php');
}

$errors = [];

if ($title === '') {
    $errors[] = 'Der Titel ist ein Pflichtfeld.';
} elseif (mb_strlen($title) > 255) {
    $errors[] = 'Der Titel darf maximal 255 Zeichen lang sein.';
}

if (!in_array($mediaType, ALLOWED_MEDIA_TYPES, true)) {
    $errors[] = 'Bitte einen gültigen Medientyp auswählen.';
}

if (!in_array($status, ALLOWED_STATUSES, true)) {
    $errors[] = 'Bitte einen gültigen Status auswählen.';
}

if (!in_array($archiveFlag, ['0', '1'], true)) {
    $errors[] = 'Ungültiger Archivierungswert.';
}

if (!empty($errors)) {
    setFlashMessage('danger', implode(' ', $errors));
    redirect('/ArchivApp/media/edit.php?id=' . $id);
}

// Fetch current record to detect status change and confirm existence
$stmt = $pdo->prepare('SELECT status FROM media WHERE id = :id LIMIT 1');
$stmt->execute(['id' => $id]);
$current = $stmt->fetch();

if (!$current) {
    setFlashMessage('danger', 'Medium nicht gefunden.');
    redirect('/ArchivApp/media/list.php');
}

$oldStatus = $current['status'];

$stmt = $pdo->prepare('
    UPDATE media
    SET
        title         = :title,
        description   = :description,
        media_type    = :media_type,
        recorded_date = :recorded_date,
        status        = :status,
        archive_flag  = :archive_flag
    WHERE id = :id
');

$stmt->execute([
    'title'         => $title,
    'description'   => $description !== '' ? $description : null,
    'media_type'    => $mediaType,
    'recorded_date' => $recordedDate !== '' ? $recordedDate : null,
    'status'        => $status,
    'archive_flag'  => (int) $archiveFlag,
    'id'            => $id,
]);

// Log status change only when it actually changed
if ($oldStatus !== $status) {
    $historyStmt = $pdo->prepare('
        INSERT INTO media_status_history (media_id, old_status, new_status, changed_by, comment)
        VALUES (:media_id, :old_status, :new_status, :changed_by, :comment)
    ');

    $historyStmt->execute([
        'media_id'   => $id,
        'old_status' => $oldStatus,
        'new_status' => $status,
        'changed_by' => (int) $_SESSION['user_id'],
        'comment'    => 'Status geändert',
    ]);
}

setFlashMessage('success', 'Medium erfolgreich aktualisiert.');
redirect('/ArchivApp/media/list.php');
