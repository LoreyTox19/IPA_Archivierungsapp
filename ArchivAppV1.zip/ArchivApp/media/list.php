<?php

declare(strict_types=1);

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/role_check.php';

requireRole(['admin', 'benutzer', 'gast']);

$searchTitle     = trim($_GET['title'] ?? '');
$searchStatus    = trim($_GET['status'] ?? '');
$searchMediaType = trim($_GET['media_type'] ?? '');

$sql = '
    SELECT
        m.id,
        m.title,
        m.description,
        m.media_type,
        m.recorded_date,
        m.status,
        m.archive_flag,
        m.created_at,
        u.name AS created_by_name
    FROM media m
    INNER JOIN users u ON m.created_by = u.id
    WHERE 1=1
';

$params = [];

if ($searchTitle !== '') {
    $sql .= ' AND m.title LIKE :title';
    $params['title'] = '%' . $searchTitle . '%';
}

if ($searchStatus !== '' && in_array($searchStatus, ALLOWED_STATUSES, true)) {
    $sql .= ' AND m.status = :status';
    $params['status'] = $searchStatus;
}

if ($searchMediaType !== '' && in_array($searchMediaType, ALLOWED_MEDIA_TYPES, true)) {
    $sql .= ' AND m.media_type = :media_type';
    $params['media_type'] = $searchMediaType;
}

$sql .= ' ORDER BY m.id DESC';

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$mediaItems = $stmt->fetchAll();

$flash = getFlashMessage();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="h2 mb-1">Medienübersicht</h1>
        <p class="text-muted mb-0">Alle erfassten Archivmedien auf einen Blick</p>
    </div>
    <div class="d-flex gap-2">
        <?php if (hasRole(['admin', 'benutzer'])): ?>
            <a href="/ArchivApp/media/create.php" class="btn btn-primary">Neues Medium</a>
        <?php endif; ?>
        <a href="/ArchivApp/dashboard.php" class="btn btn-outline-secondary">Zurück zum Dashboard</a>
    </div>
</div>

<?php if ($flash): ?>
    <div class="alert alert-<?php echo escape($flash['type']); ?>">
        <?php echo escape($flash['message']); ?>
    </div>
<?php endif; ?>

<div class="card shadow-sm mb-4">
    <div class="card-body">
        <h2 class="h5 mb-3">Suche und Filter</h2>

        <form method="get" action="/ArchivApp/media/list.php">
            <div class="row g-3">
                <div class="col-md-4">
                    <label for="title" class="form-label">Titel suchen</label>
                    <input
                        type="text"
                        class="form-control"
                        id="title"
                        name="title"
                        value="<?php echo escape($searchTitle); ?>"
                        placeholder="z. B. Lifestyle">
                </div>

                <div class="col-md-3">
                    <label for="status" class="form-label">Status</label>
                    <select class="form-select" id="status" name="status">
                        <option value="">Alle</option>
                        <?php foreach (ALLOWED_STATUSES as $status): ?>
                            <option value="<?php echo escape($status); ?>" <?php echo $searchStatus === $status ? 'selected' : ''; ?>>
                                <?php echo escape($status); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="col-md-3">
                    <label for="media_type" class="form-label">Medientyp</label>
                    <select class="form-select" id="media_type" name="media_type">
                        <option value="">Alle</option>
                        <?php foreach (ALLOWED_MEDIA_TYPES as $type): ?>
                            <option value="<?php echo escape($type); ?>" <?php echo $searchMediaType === $type ? 'selected' : ''; ?>>
                                <?php echo escape($type); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="col-md-2 d-flex align-items-end">
                    <div class="d-grid gap-2 w-100">
                        <button type="submit" class="btn btn-primary">Filtern</button>
                        <a href="/ArchivApp/media/list.php" class="btn btn-outline-secondary">Zurücksetzen</a>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

<div class="card shadow-sm">
    <div class="card-body">
        <?php if (empty($mediaItems)): ?>
            <div class="alert alert-info mb-0">
                Keine Medien für die gewählten Suchkriterien gefunden.
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-striped table-hover align-middle">
                    <thead class="table-dark">
                        <tr>
                            <th>ID</th>
                            <th>Titel</th>
                            <th>Typ</th>
                            <th>Aufnahmedatum</th>
                            <th>Status</th>
                            <th>Archiviert</th>
                            <th>Erstellt von</th>
                            <th>Erstellt am</th>
                            <th>Aktionen</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($mediaItems as $item): ?>
                            <tr>
                                <td><?php echo (int) $item['id']; ?></td>
                                <td>
                                    <strong><?php echo escape($item['title']); ?></strong>
                                    <?php if (!empty($item['description'])): ?>
                                        <div class="small text-muted">
                                            <?php echo escape($item['description']); ?>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo escape($item['media_type']); ?></td>
                                <td><?php echo escape($item['recorded_date'] ?? '-'); ?></td>
                                <td><?php echo escape($item['status']); ?></td>
                                <td><?php echo (int) $item['archive_flag'] === 1 ? 'Ja' : 'Nein'; ?></td>
                                <td><?php echo escape($item['created_by_name']); ?></td>
                                <td><?php echo escape($item['created_at']); ?></td>
                                <td>
                                    <div class="d-flex gap-2 flex-wrap">
                                        <a href="/ArchivApp/media/detail.php?id=<?php echo (int) $item['id']; ?>" class="btn btn-sm btn-outline-secondary">
                                            Details
                                        </a>

                                        <?php if (hasRole(['admin', 'benutzer'])): ?>
                                            <a href="/ArchivApp/media/edit.php?id=<?php echo (int) $item['id']; ?>" class="btn btn-sm btn-outline-primary">
                                                Bearbeiten
                                            </a>
                                        <?php endif; ?>

                                        <?php if (isAdmin()): ?>
                                            <form action="/ArchivApp/media/delete.php" method="post"
                                                onsubmit="return confirm('Möchtest du dieses Medium wirklich löschen?');">
                                                <?php echo csrfField(); ?>
                                                <input type="hidden" name="id" value="<?php echo (int) $item['id']; ?>">
                                                <button type="submit" class="btn btn-sm btn-outline-danger">Löschen</button>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
