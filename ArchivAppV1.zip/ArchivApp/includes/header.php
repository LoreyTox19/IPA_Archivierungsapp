<?php

declare(strict_types=1);

require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/role_check.php';
?>
<!DOCTYPE html>
<html lang="de">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ArchivApp</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="/ArchivApp/dashboard.php">ArchivApp</a>

            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNavbar"
                aria-controls="mainNavbar" aria-expanded="false" aria-label="Navigation umschalten">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="mainNavbar">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="/ArchivApp/dashboard.php">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/ArchivApp/media/list.php">Medien</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/ArchivApp/history/list.php">Historie</a>
                    </li>
                    <?php if (isAdmin()): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="/ArchivApp/users/list.php">Benutzer</a>
                        </li>
                    <?php endif; ?>
                </ul>

                <div class="d-flex align-items-center text-white">
                    <?php if (isLoggedIn()): ?>
                        <span class="me-3">
                            <?php echo escape($_SESSION['user_name'] ?? 'Benutzer'); ?>
                        </span>
                        <a href="/ArchivApp/logout.php" class="btn btn-outline-light btn-sm">Logout</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
