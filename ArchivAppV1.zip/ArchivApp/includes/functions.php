<?php

declare(strict_types=1);

// Session must be started before any session usage
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function redirect(string $path): void
{
    header('Location: ' . $path);
    exit;
}

function escape(?string $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function isPostRequest(): bool
{
    return $_SERVER['REQUEST_METHOD'] === 'POST';
}

function isLoggedIn(): bool
{
    return isset($_SESSION['user_id']);
}

function setFlashMessage(string $type, string $message): void
{
    $_SESSION['flash'] = [
        'type'    => $type,
        'message' => $message,
    ];
}

function getFlashMessage(): ?array
{
    if (!isset($_SESSION['flash'])) {
        return null;
    }

    $flash = $_SESSION['flash'];
    unset($_SESSION['flash']);

    return $flash;
}

function generateCsrfToken(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }

    return $_SESSION['csrf_token'];
}

function csrfField(): string
{
    return '<input type="hidden" name="csrf_token" value="' . escape(generateCsrfToken()) . '">';
}

function validateCsrfToken(): void
{
    $sessionToken = $_SESSION['csrf_token'] ?? '';
    $formToken    = $_POST['csrf_token'] ?? '';

    if ($sessionToken === '' || $formToken === '' || !hash_equals($sessionToken, $formToken)) {
        http_response_code(403);
        exit('Ungültiger CSRF-Token.');
    }
}
