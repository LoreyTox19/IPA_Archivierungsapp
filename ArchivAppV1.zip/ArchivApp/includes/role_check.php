<?php

declare(strict_types=1);

require_once __DIR__ . '/functions.php';

function getCurrentUserRole(): ?string
{
    return $_SESSION['user_role'] ?? null;
}

function hasRole(array $allowedRoles): bool
{
    $role = getCurrentUserRole();

    return $role !== null && in_array($role, $allowedRoles, true);
}

function requireRole(array $allowedRoles): void
{
    if (!isLoggedIn()) {
        setFlashMessage('danger', 'Bitte zuerst einloggen.');
        redirect('/ArchivApp/login.php');
    }

    if (!hasRole($allowedRoles)) {
        http_response_code(403);
        exit('Kein Zugriff auf diese Funktion.');
    }
}

function isAdmin(): bool
{
    return hasRole(['admin']);
}
