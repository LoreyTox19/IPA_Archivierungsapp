<?php

declare(strict_types=1);

const ALLOWED_MEDIA_TYPES = ['Betacam', 'VHS', 'MiniDV', 'DVD', 'Festplatte', 'Blu-ray', 'CD', 'Audio-CD', 'Schallplatte', 'USB-Stick', 'SD-Karte', 'MicroSD-Karte', 'SSD', 'Cloud-Speicher'];
const ALLOWED_STATUSES    = ['erfasst', 'in_digitalisierung', 'digitalisiert'];
const ALLOWED_ROLES       = ['admin', 'benutzer', 'gast'];
