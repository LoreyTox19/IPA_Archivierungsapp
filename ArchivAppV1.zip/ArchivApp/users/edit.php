<?php

declare(strict_types=1);

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/role_check.php';

requireRole(['admin']);

$id = (int) ($_GET['id'] ?? 0);

if ($id <= 0) {
    setFlashMessage('danger', 'Ungültige Benutzer-ID.');
    redirect('/ArchivApp/users/list.php');
}

$stmt = $pdo->prepare('
    SELECT id, name, email, role, created_at
    FROM users
    WHERE id = :id
    LIMIT 1
');
$stmt->execute(['id' => $id]);
$user = $stmt->fetch();

if (!$user) {
    setFlashMessage('danger', 'Benutzer nicht gefunden.');
    redirect('/ArchivApp/users/list.php');
}

// Merge session repopulation data over the DB values on validation failure
$old   = $_SESSION['old_user_edit'] ?? [];
$flash = getFlashMessage();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="h2 mb-1">Benutzer bearbeiten</h1>
        <p class="text-muted mb-0"><?php echo escape($user['name']); ?></p>
    </div>
    <a href="/ArchivApp/users/list.php" class="btn btn-outline-secondary">Zurück zur Benutzerübersicht</a>
</div>

<?php if ($flash): ?>
    <div class="alert alert-<?php echo escape($flash['type']); ?>">
        <?php echo escape($flash['message']); ?>
    </div>
<?php endif; ?>

<div class="card shadow-sm">
    <div class="card-body">
        <form action="/ArchivApp/users/update.php" method="post">
            <?php echo csrfField(); ?>
            <input type="hidden" name="id" value="<?php echo (int) $user['id']; ?>">

            <div class="row g-3">
                <div class="col-md-6">
                    <label for="name" class="form-label">Name *</label>
                    <input
                        type="text"
                        class="form-control"
                        id="name"
                        name="name"
                        required
                        maxlength="100"
                        value="<?php echo escape($old['name'] ?? $user['name']); ?>">
                </div>

                <div class="col-md-6">
                    <label for="email" class="form-label">E-Mail *</label>
                    <input
                        type="email"
                        class="form-control"
                        id="email"
                        name="email"
                        required
                        maxlength="150"
                        value="<?php echo escape($old['email'] ?? $user['email']); ?>">
                </div>

                <div class="col-md-6">
                    <label for="password" class="form-label">Neues Passwort</label>
                    <input
                        type="password"
                        class="form-control"
                        id="password"
                        name="password">
                    <div class="form-text">
                        Leer lassen, wenn das Passwort nicht geändert werden soll.
                    </div>
                </div>

                <div class="col-md-6">
                    <label for="role" class="form-label">Rolle *</label>
                    <select class="form-select" id="role" name="role" required>
                        <?php foreach (ALLOWED_ROLES as $role): ?>
                            <option value="<?php echo escape($role); ?>"
                                <?php echo ($old['role'] ?? $user['role']) === $role ? 'selected' : ''; ?>>
                                <?php echo escape($role); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <div class="mt-4 d-flex gap-2">
                <button type="submit" class="btn btn-primary">Änderungen speichern</button>
                <a href="/ArchivApp/users/list.php" class="btn btn-outline-secondary">Abbrechen</a>
            </div>
        </form>
    </div>
</div>

<?php
unset($_SESSION['old_user_edit']);
require_once __DIR__ . '/../includes/footer.php';
?>
