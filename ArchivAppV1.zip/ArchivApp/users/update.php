<?php

declare(strict_types=1);

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/role_check.php';

requireRole(['admin']);

if (!isPostRequest()) {
    redirect('/ArchivApp/users/list.php');
}

validateCsrfToken();

$id       = (int) ($_POST['id'] ?? 0);
$name     = trim($_POST['name'] ?? '');
$email    = trim($_POST['email'] ?? '');
$password = $_POST['password'] ?? '';
$role     = trim($_POST['role'] ?? '');

if ($id <= 0) {
    setFlashMessage('danger', 'Ungültige Benutzer-ID.');
    redirect('/ArchivApp/users/list.php');
}

$_SESSION['old_user_edit'] = [
    'name'  => $name,
    'email' => $email,
    'role'  => $role,
];

$errors = [];

if ($name === '') {
    $errors[] = 'Der Name ist ein Pflichtfeld.';
} elseif (mb_strlen($name) > 100) {
    $errors[] = 'Der Name darf maximal 100 Zeichen lang sein.';
}

if ($email === '') {
    $errors[] = 'Die E-Mail ist ein Pflichtfeld.';
} elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors[] = 'Bitte eine gültige E-Mail-Adresse eingeben.';
}

if (!in_array($role, ALLOWED_ROLES, true)) {
    $errors[] = 'Bitte eine gültige Rolle auswählen.';
}

if ($password !== '' && mb_strlen($password) < 6) {
    $errors[] = 'Das neue Passwort muss mindestens 6 Zeichen lang sein.';
}

// Confirm user exists
$stmt = $pdo->prepare('SELECT id FROM users WHERE id = :id LIMIT 1');
$stmt->execute(['id' => $id]);

if (!$stmt->fetch()) {
    setFlashMessage('danger', 'Benutzer nicht gefunden.');
    redirect('/ArchivApp/users/list.php');
}

// Check e-mail uniqueness, excluding the current user
$emailCheckStmt = $pdo->prepare('SELECT id FROM users WHERE email = :email AND id != :id LIMIT 1');
$emailCheckStmt->execute(['email' => $email, 'id' => $id]);

if ($emailCheckStmt->fetch()) {
    $errors[] = 'Die E-Mail-Adresse ist bereits vergeben.';
}

if (!empty($errors)) {
    setFlashMessage('danger', implode(' ', $errors));
    redirect('/ArchivApp/users/edit.php?id=' . $id);
}

// Build a single UPDATE that optionally includes the password column
$params = [
    'name'  => $name,
    'email' => $email,
    'role'  => $role,
    'id'    => $id,
];

$passwordSql = '';

if ($password !== '') {
    $passwordSql      = 'password_hash = :password_hash,';
    $params['password_hash'] = password_hash($password, PASSWORD_DEFAULT);
}

$stmt = $pdo->prepare("
    UPDATE users
    SET
        {$passwordSql}
        name  = :name,
        email = :email,
        role  = :role
    WHERE id = :id
");

$stmt->execute($params);

unset($_SESSION['old_user_edit']);

setFlashMessage('success', 'Benutzer erfolgreich aktualisiert.');
redirect('/ArchivApp/users/list.php');
