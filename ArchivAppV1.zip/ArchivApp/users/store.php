<?php

declare(strict_types=1);

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/role_check.php';

requireRole(['admin']);

if (!isPostRequest()) {
    redirect('/ArchivApp/users/create.php');
}

validateCsrfToken();

$name     = trim($_POST['name'] ?? '');
$email    = trim($_POST['email'] ?? '');
$password = $_POST['password'] ?? '';
$role     = trim($_POST['role'] ?? '');

// Preserve form input for redirect-back on validation failure
$_SESSION['old_user'] = [
    'name'  => $name,
    'email' => $email,
    'role'  => $role,
];

$errors = [];

if ($name === '') {
    $errors[] = 'Der Name ist ein Pflichtfeld.';
} elseif (mb_strlen($name) > 100) {
    $errors[] = 'Der Name darf maximal 100 Zeichen lang sein.';
}

if ($email === '') {
    $errors[] = 'Die E-Mail ist ein Pflichtfeld.';
} elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors[] = 'Bitte eine gültige E-Mail-Adresse eingeben.';
}

if ($password === '') {
    $errors[] = 'Das Passwort ist ein Pflichtfeld.';
} elseif (mb_strlen($password) < 6) {
    $errors[] = 'Das Passwort muss mindestens 6 Zeichen lang sein.';
}

if (!in_array($role, ALLOWED_ROLES, true)) {
    $errors[] = 'Bitte eine gültige Rolle auswählen.';
}

// Check for duplicate e-mail only when the address itself looks valid
if (empty($errors) || !in_array('Bitte eine gültige E-Mail-Adresse eingeben.', $errors, true)) {
    $checkStmt = $pdo->prepare('SELECT id FROM users WHERE email = :email LIMIT 1');
    $checkStmt->execute(['email' => $email]);

    if ($checkStmt->fetch()) {
        $errors[] = 'Die E-Mail-Adresse ist bereits vergeben.';
    }
}

if (!empty($errors)) {
    setFlashMessage('danger', implode(' ', $errors));
    redirect('/ArchivApp/users/create.php');
}

$stmt = $pdo->prepare('
    INSERT INTO users (name, email, password_hash, role)
    VALUES (:name, :email, :password_hash, :role)
');

$stmt->execute([
    'name'          => $name,
    'email'         => $email,
    'password_hash' => password_hash($password, PASSWORD_DEFAULT),
    'role'          => $role,
]);

unset($_SESSION['old_user']);

setFlashMessage('success', 'Der Benutzer wurde erfolgreich erstellt.');
redirect('/ArchivApp/users/list.php');
