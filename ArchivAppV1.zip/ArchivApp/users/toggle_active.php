<?php

declare(strict_types=1);

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/role_check.php';

requireRole(['admin']);

if (!isPostRequest()) {
    redirect('/ArchivApp/users/list.php');
}

validateCsrfToken();

$userId        = (int) ($_POST['id'] ?? 0);
$currentUserId = (int) ($_SESSION['user_id'] ?? 0);

if ($userId <= 0) {
    setFlashMessage('danger', 'Ungültige Benutzer-ID.');
    redirect('/ArchivApp/users/list.php');
}

$stmt = $pdo->prepare('SELECT id, name, role, is_active FROM users WHERE id = :id LIMIT 1');
$stmt->execute(['id' => $userId]);
$user = $stmt->fetch();

if (!$user) {
    setFlashMessage('danger', 'Benutzer nicht gefunden.');
    redirect('/ArchivApp/users/list.php');
}

// Prevent an admin from deactivating themselves
if ($userId === $currentUserId && (int) $user['is_active'] === 1) {
    setFlashMessage('danger', 'Du kannst deinen eigenen Benutzer nicht deaktivieren.');
    redirect('/ArchivApp/users/list.php');
}

// Prevent deactivating the last active admin
if ($user['role'] === 'admin' && (int) $user['is_active'] === 1) {
    $countStmt       = $pdo->query("SELECT COUNT(*) AS admin_count FROM users WHERE role = 'admin' AND is_active = 1");
    $activeAdminCount = (int) $countStmt->fetch()['admin_count'];

    if ($activeAdminCount <= 1) {
        setFlashMessage('danger', 'Der letzte aktive Administrator kann nicht deaktiviert werden.');
        redirect('/ArchivApp/users/list.php');
    }
}

$newStatus = (int) $user['is_active'] === 1 ? 0 : 1;

$updateStmt = $pdo->prepare('UPDATE users SET is_active = :is_active WHERE id = :id');
$updateStmt->execute(['is_active' => $newStatus, 'id' => $userId]);

$message = $newStatus === 1
    ? 'Der Benutzer "' . $user['name'] . '" wurde reaktiviert.'
    : 'Der Benutzer "' . $user['name'] . '" wurde deaktiviert.';

setFlashMessage('success', $message);
redirect('/ArchivApp/users/list.php');
