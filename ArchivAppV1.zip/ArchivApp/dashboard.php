<?php

declare(strict_types=1);

require_once __DIR__ . '/includes/auth_check.php';
require_once __DIR__ . '/includes/role_check.php';

$flash = getFlashMessage();

require_once __DIR__ . '/includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="h2 mb-1">Dashboard</h1>
        <p class="text-muted mb-0">
            Willkommen, <?php echo escape($_SESSION['user_name'] ?? 'Benutzer'); ?>
        </p>
    </div>
    <a href="/ArchivApp/logout.php" class="btn btn-outline-danger">Logout</a>
</div>

<?php if ($flash): ?>
    <div class="alert alert-<?php echo escape($flash['type']); ?>">
        <?php echo escape($flash['message']); ?>
    </div>
<?php endif; ?>

<div class="row g-4">
    <div class="col-md-4">
        <div class="card shadow-sm h-100">
            <div class="card-body">
                <h2 class="h5">Medienverwaltung</h2>
                <p class="mb-3">Medien erfassen, bearbeiten und durchsuchen.</p>
                <a href="/ArchivApp/media/list.php" class="btn btn-primary">Zu den Medien</a>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card shadow-sm h-100">
            <div class="card-body">
                <h2 class="h5">Statusverlauf</h2>
                <p class="mb-3">Statusänderungen und Historie anzeigen.</p>
                <a href="/ArchivApp/history/list.php" class="btn btn-outline-primary">Zur Historie</a>
            </div>
        </div>
    </div>

    <?php if (isAdmin()): ?>
    <div class="col-md-4">
        <div class="card shadow-sm h-100">
            <div class="card-body">
                <h2 class="h5">Benutzer</h2>
                <p class="mb-3">Benutzer und Rollen verwalten.</p>
                <a href="/ArchivApp/users/list.php" class="btn btn-outline-secondary">Zu den Benutzern</a>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
