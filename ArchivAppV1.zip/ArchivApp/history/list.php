<?php

declare(strict_types=1);

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/role_check.php';

requireRole(['admin', 'benutzer', 'gast']);

$stmt = $pdo->query('
    SELECT
        msh.id,
        msh.media_id,
        msh.old_status,
        msh.new_status,
        msh.changed_at,
        msh.comment,
        m.title AS media_title,
        u.name  AS changed_by_name
    FROM media_status_history msh
    INNER JOIN media m  ON msh.media_id   = m.id
    INNER JOIN users u  ON msh.changed_by = u.id
    ORDER BY msh.changed_at DESC, msh.id DESC
');

$historyItems = $stmt->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="h2 mb-1">Statusverlauf</h1>
        <p class="text-muted mb-0">Übersicht aller Statusänderungen der Archivmedien</p>
    </div>
    <a href="/ArchivApp/dashboard.php" class="btn btn-outline-secondary">Zurück zum Dashboard</a>
</div>

<div class="card shadow-sm">
    <div class="card-body">
        <?php if (empty($historyItems)): ?>
            <div class="alert alert-info mb-0">
                Es sind aktuell keine Statusänderungen vorhanden.
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-striped table-hover align-middle">
                    <thead class="table-dark">
                        <tr>
                            <th>ID</th>
                            <th>Medium</th>
                            <th>Alter Status</th>
                            <th>Neuer Status</th>
                            <th>Geändert von</th>
                            <th>Geändert am</th>
                            <th>Kommentar</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($historyItems as $item): ?>
                            <tr>
                                <td><?php echo (int) $item['id']; ?></td>
                                <td>
                                    <a href="/ArchivApp/media/detail.php?id=<?php echo (int) $item['media_id']; ?>">
                                        <?php echo escape($item['media_title']); ?>
                                    </a>
                                </td>
                                <td><?php echo escape($item['old_status'] ?? '-'); ?></td>
                                <td><?php echo escape($item['new_status']); ?></td>
                                <td><?php echo escape($item['changed_by_name']); ?></td>
                                <td><?php echo escape($item['changed_at']); ?></td>
                                <td><?php echo escape($item['comment'] ?? '-'); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
